package com.br.Projeto2024Alex.ProjetoComDTO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoComDtoApplicationTests {

	@Test
	void contextLoads() {
	}

}
